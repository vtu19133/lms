# Online Leave Management System
The project is the design and implementation of an interactive Online Leave Management
System for the local Educational Institute. The Leave Management System automates the process
of managing and tracking multiple types of staff leaves. Staff are able to submit the leave
requests, check the status of their leave requests and view completed leave transactions. The
Leave Management System maintains a database to keep a running balance of each staff’s
account and keeps track of all the leave requests and calculates the leave balances of each
employee. This project basically involves three  users – 

i) Staff

ii) Program Coordinator

iii) Administrator




